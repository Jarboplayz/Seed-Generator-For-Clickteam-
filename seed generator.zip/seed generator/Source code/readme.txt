So, if you don't know, the source code is a ".mfa" file. This will work for the game engine,
"Clickteam fusion." this could run on free version of it. It is available on steam or you can
download it in the original website.

Website of clickteam: www.clickteam.com